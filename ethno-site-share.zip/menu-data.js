window.ethnoMenuData = [
  {
    id: 'drinks',
    title: { ru: 'Напитки', en: 'Drinks', kk: 'Сусындар' },
    sections: [
      {
        id: 'lemonades',
        title: { ru: 'Лимонады', en: 'Lemonades', kk: 'Лимонадтар' },
        items: [
          { name: 'Копченный Ананас', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Драгонфрукт-личи', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Малина-маракуйя', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Экзотик', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Клубника-Фейхоа-Барбарис', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Каркадэ-гранат', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Свежесть', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Облепиха-апельсин', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Яблоко-Апельсин', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' },
          { name: 'Яблоко-Страгон', size: '0.4 л / 1.2 л', price: '1 390 / 3 990 ₸' }
        ]
      },
      {
        id: 'fresh-juice',
        title: { ru: 'Фреш (0.35 л)', en: 'Fresh juice (0.35 L)', kk: 'Фреш (0.35 л)' },
        items: [
          { name: 'Яблочный', price: '2 490 ₸' },
          { name: 'Апельсиновый', price: '2 490 ₸' },
          { name: 'Ананас', price: '2 990 ₸' },
          { name: 'Морковный', price: '1 990 ₸' }
        ]
      },
      {
        id: 'milkshakes',
        title: { ru: 'Молочные коктейли', en: 'Milkshakes', kk: 'Сүт коктейльдері' },
        items: [
          { name: 'Банановый', price: '2 590 ₸' },
          { name: 'Шоколадный', price: '2 590 ₸' },
          { name: 'Клубничный', price: '2 590 ₸' },
          { name: 'Ореховый', price: '2 590 ₸' },
          { name: 'Oreo', price: '2 590 ₸' }
        ]
      },
      {
        id: 'soft-drinks',
        title: { ru: 'Прохладительные напитки', en: 'Soft drinks', kk: 'Салқын сусындар' },
        items: [
          { name: 'Coca-cola / Coca-cola zero / Sprite / Fanta', size: '0.25 л', price: '990 ₸' },
          { name: 'Coca-cola / Sprite', size: '1 л', price: '1 490 ₸' },
          { name: 'Coca-cola / Sprite / Fanta', size: '0.5 л', price: '690 ₸' },
          { name: 'Tassay стекло с газом / без газа', size: '0.5 л', price: '1 490 ₸' },
          { name: 'Морс', size: '0.35 л / 1.2 л', price: '690 / 1 990 ₸' },
          { name: 'Сок в ассортименте', size: '0.35 л / 1 л', price: '890 / 1 790 ₸' },
          { name: 'Сок с трубочкой в ассортименте', size: '0.2 л', price: '690 ₸' },
          { name: 'Fuse Tea в ассортименте', size: '0.5 л', price: '990 ₸' },
          { name: 'Red Bull', size: '0.25 л', price: '1 690 ₸' },
          { name: 'Borjomi', size: '0.5 л', price: '1 590 ₸' },
          { name: 'Tonic', size: '0.45 л', price: '1 190 ₸' },
          { name: 'Bon Aqua', size: '0.5 л', price: '690 ₸' },
          { name: 'Tassay Excellent', size: '0.75 л', price: '3 490 ₸' },
          { name: 'Tassay Emerald', size: '0.75 л', price: '3 490 ₸' }
        ]
      },
      {
        id: 'national-drinks',
        title: { ru: 'Национальные напитки', en: 'Traditional drinks', kk: 'Ұлттық сусындар' },
        items: [
          { name: 'Кымыз', size: '0.5 л / 1 л', price: '2 490 / 3 990 ₸' },
          { name: 'Шубат', size: '0.5 л / 1 л', price: '1 290 / 2 490 ₸' },
          { name: 'Айран', size: '0.5 л / 1 л', price: '890 / 1 490 ₸' },
          { name: 'Этно', description: 'Банан, финики, лесной орех, кымыз', price: '3 290 ₸' }
        ]
      },
      {
        id: 'smoothies',
        title: { ru: 'Смузи', en: 'Smoothies', kk: 'Смузи' },
        items: [
          { name: 'Ананас-малина', price: '3 290 ₸' },
          { name: 'Клубника-Банан-Ваниль', price: '2 990 ₸' },
          { name: 'Киви-мята', price: '2 990 ₸' },
          { name: 'Банан-Финик-Кофе', price: '2 990 ₸' }
        ]
      },
      {
        id: 'ice-tea',
        title: { ru: 'Ice Tea', en: 'Ice Tea', kk: 'Ice Tea' },
        items: [
          { name: 'Манго-жасмин', price: '2 790 ₸' },
          { name: 'Ананас-кокос', price: '2 790 ₸' },
          { name: 'Облепиха-Апельсин', price: '2 790 ₸' },
          { name: 'Киви-Алоэ', price: '2 790 ₸' },
          { name: 'Смородина-мята', price: '2 790 ₸' },
          { name: 'Яблоко-Страгон', price: '2 790 ₸' }
        ]
      },
      {
        id: 'coffee',
        title: { ru: 'Кофе', en: 'Coffee', kk: 'Кофе' },
        items: [
          { name: 'Эспрессо', size: '0.03 л', price: '590 ₸' },
          { name: 'Американо', size: '0.2 л', price: '690 ₸' },
          { name: 'Капучино', size: '0.25 л', price: '1 190 ₸' },
          { name: 'Латте', size: '0.4 л', price: '1 390 ₸' },
          { name: 'Раф', size: '0.4 л', price: '2 090 ₸' },
          { name: 'Гляссе', size: '0.4 л', price: '2 490 ₸' }
        ]
      },
      {
        id: 'tea',
        title: { ru: 'Чай (0.9 л)', en: 'Tea (0.9 L)', kk: 'Шай (0.9 л)' },
        items: [
          { name: 'Чёрный чай · Кения', price: '1 690 ₸' },
          { name: 'Чёрный чай · Эрл грей', price: '1 690 ₸' },
          { name: 'Чёрный чай · С чабрецом', price: '1 690 ₸' },
          { name: 'Чёрный чай · Масала', price: '1 990 ₸' },
          { name: 'Зелёный чай · Мао Фен Люй Ча', price: '1 690 ₸' },
          { name: 'Зелёный чай · Жасминовый чай', price: '1 990 ₸' },
          { name: 'Зелёный чай · Молочный Улун', price: '1 690 ₸' },
          { name: 'Китайский чай · Шу пуэр', price: '2 390 ₸' },
          { name: 'Китайский чай · Лапсанг Сушонг', price: '2 390 ₸' },
          { name: 'Травяной чай · Вишневый ройбуш', price: '1 990 ₸' },
          { name: 'Фруктовый чай · Ташкентский', price: '2 490 ₸' },
          { name: 'Фруктовый чай · По-казахский', price: '2 490 ₸' },
          { name: 'Фруктовый чай · Марокканский', price: '2 490 ₸' },
          { name: 'Фруктовый чай · Облепиховый', price: '2 490 ₸' },
          { name: 'Фруктовый чай · Восточная роза', price: '2 490 ₸' },
          { name: 'Фруктовый чай · Жемчужина оазиса', price: '2 490 ₸' }
        ]
      },
      {
        id: 'hot-drinks',
        title: { ru: 'Горячие напитки', en: 'Hot drinks', kk: 'Ыстық сусындар' },
        items: [
          { name: 'Горячий шоколад', price: '2 490 ₸' },
          { name: 'Какао', price: '2 490 ₸' },
          { name: 'Безалкогольный глинтвейн (белый / красный)', price: '2 590 ₸' }
        ]
      },
      {
        id: 'extras',
        title: { ru: 'Дополнительно', en: 'Extras', kk: 'Қосымша' },
        items: [
          { name: 'Лимон', price: '790 ₸' },
          { name: 'Апельсин', price: '890 ₸' },
          { name: 'Лайм', price: '890 ₸' },
          { name: 'Мёд', price: '490 ₸' },
          { name: 'Молоко', price: '490 ₸' },
          { name: 'Шоколад', price: '2 490 ₸' },
          { name: 'Сироп в ассортименте', price: '690 ₸' }
        ]
      }
    ]
  },
  {
    id: 'food',
    title: { ru: 'Основное меню', en: 'Main menu', kk: 'Негізгі мәзір' },
    sections: [
      {
        id: 'cold-starters',
        title: { ru: 'Холодные закуски', en: 'Cold starters', kk: 'Салқын тіскебасарлар' },
        items: [
          { name: 'Рыбное плато', description: 'Семга м/соль, масляная, тигровые креветки', price: '5 900 ₸' },
          { name: 'Карпаччо из благородной рыбы', description: 'Семга м/с, лук, каперсы, лимон', price: '3 900 ₸' },
          { name: 'Мясное плато «Улы Дала»', description: 'Мозговая кость, казы, жая, язык, шужык, курт', price: '6 800 ₸' },
          { name: 'Брускетты «Кочевник»', description: 'Шелпек, казы, перепелиное яйцо, вяленые томаты, мусс', price: '4 200 ₸' },
          { name: 'Брускетты «Шёлковый путь»', description: 'Шелпек, творожный сыр с кремовым соусом', price: '4 200 ₸' },
          { name: 'Язык под соусом Вителло Тоннато', description: 'Нежный говяжий язык с кремовым соусом на основе тунца и каперсов', price: '4 000 ₸' },
          { name: 'Карпаччо из печеной свеклы и утки', description: 'Печеная свекла, филе утки', price: '4 200 ₸' },
          { name: 'Фреш плато', description: 'Огурец, помидоры, перец цветной, редис, сельдерей, зелень', price: '4 200 ₸' },
          { name: 'Ассорти мезе с домашней лепешкой', price: '3 500 ₸' }
        ]
      },
      {
        id: 'hot-starters',
        title: { ru: 'Горячие закуски', en: 'Hot starters', kk: 'Ыстық тіскебасарлар' },
        items: [
          { name: 'Запеченная мозговая кость', price: '3 800 ₸' },
          { name: 'Шелпек с говядиной', price: '2 400 ₸' },
          { name: 'Шелпек с кониной', price: '2 800 ₸' },
          { name: 'Мини самса с мясом', price: '1 700 ₸' },
          { name: 'Фалафель с соусом дзадзики', price: '1 200 ₸' }
        ]
      },
      {
        id: 'soups',
        title: { ru: 'Супы', en: 'Soups', kk: 'Сорпалар' },
        items: [
          { name: 'Рыбный суп', description: 'Наваристый суп на тройном бульоне из осетра, семги и судака', price: '4 900 ₸' },
          { name: 'Коже с копчённостями', description: 'Холодный суп на айране с копченой говядиной и жая, подается с баурсаками', price: '5 100 ₸' },
          { name: 'Шурпа из баранины', price: '3 800 ₸' },
          { name: 'Нохат шурпа', price: '3 800 ₸' },
          { name: 'Шпинатный крем-суп с копченой курицей', price: '3 400 ₸' },
          { name: 'Кеспе с домашней лапшой', price: '1 900 ₸' },
          { name: 'Чечевичный крем-суп', price: '1 900 ₸' },
          { name: 'Коже летний', price: '1 900 ₸' }
        ]
      },
      {
        id: 'salads',
        title: { ru: 'Салаты', en: 'Salads', kk: 'Салаттар' },
        items: [
          { name: 'Салат с киноа и языком', description: 'Печеная тыква, киноа, зелень, цукини, томаты, кунжут, сезонная зелень', price: '5 500 ₸' },
          { name: 'Салат Цезарь с курицей', description: 'Куриное филе запеченное, микс салата, гренки, сыр пармезан', price: '3 900 ₸' },
          { name: 'Салат Цезарь с креветкой', price: '4 100 ₸' },
          { name: 'Салат Цезарь с уткой', description: 'Филе утки запеченное, микс салата, гренки, яйцо перепелиное, черри, сыр пармезан', price: '4 100 ₸' },
          { name: 'Большой зеленый салат', description: 'Микс зелени, огурцы, семечки тыквы, фирменный соус', price: '3 900 ₸' },
          { name: 'Салат Греко с брынзой', description: 'Огурцы, помидоры, перец цветной', price: '3 800 ₸' },
          { name: 'Салат Женип', description: 'Микс томатов, лук красный, копченый курт', price: '2 800 ₸' },
          { name: 'Хрустящие баклажаны', price: '3 700 ₸' },
          { name: 'Салат с печеной тыквой и козьим сыром', price: '3 800 ₸' },
          { name: 'Салат по-домашнему', description: 'На выбор: майонез, сметана, масло; подается с домашней лепешкой', price: '1 800 ₸' }
        ]
      },
      {
        id: 'fish',
        title: { ru: 'Блюда из рыбы', en: 'Fish dishes', kk: 'Балық тағамдары' },
        items: [
          { name: 'Стейк из осетрины с картофелем', price: '8 500 ₸' },
          { name: 'Стейк из семги с диким рисом', price: '8 800 ₸' },
          { name: 'Дорадо на гриле', price: '6 800 ₸' },
          { name: 'Судак с зеленым пюре', price: '5 600 ₸' },
          { name: 'Филе кефали с сальсой', price: '4 600 ₸' }
        ]
      },
      {
        id: 'national-cuisine',
        title: { ru: 'Национальная кухня', en: 'Traditional cuisine', kk: 'Ұлттық тағамдар' },
        items: [
          { name: 'Фишбармак', price: '5 800 ₸' },
          { name: 'Куырдак из осетрины', price: '5 800 ₸' },
          { name: 'Бешбармак из конины', price: '5 200 ₸' },
          { name: 'Әсіп из мяса конины', price: '7 600 ₸' },
          { name: 'Хан куырдак из конины и говядины', price: '5 300 ₸' },
          { name: 'Казан кебаб из баранины', price: '5 200 ₸' },
          { name: 'Куырдак из говядины', price: '4 900 ₸' },
          { name: 'Казы саума', price: '5 600 ₸' },
          { name: 'Тай кабырга', price: '4 800 ₸' },
          { name: 'Карын куырдак', price: '2 800 ₸' }
        ]
      },
      {
        id: 'hot-dishes',
        title: { ru: 'Горячие блюда', en: 'Main courses', kk: 'Ыстық тағамдар' },
        items: [
          { name: 'Томленые говяжьи щечки с пюре', price: '4 900 ₸' },
          { name: 'Ньоки с рваным мясом говядины', price: '5 700 ₸' },
          { name: 'Ризотто в тюркском стиле', description: 'Рис Арборио, ребро конины, соус на основе курта, шампиньоны', price: '7 600 ₸' },
          { name: 'Цыпленок табака', price: '4 400 ₸' },
          { name: 'Кордон блю из курицы', price: '3 900 ₸' },
          { name: 'Маришаль из курицы', price: '4 200 ₸' },
          { name: 'Утиное филе с рататуем', price: '3 900 ₸' },
          { name: 'Утиное филе с чечевицей', price: '3 900 ₸' },
          { name: 'Куриное филе со шпинатом в грибном соусе', price: '3 900 ₸' },
          { name: 'Курочка карри с рисом', price: '2 800 ₸' },
          { name: 'Бургер Етно с томлеными щечками', price: '3 700 ₸' },
          { name: 'Стейк бургер', price: '4 200 ₸' }
        ]
      },
      {
        id: 'steaks',
        title: { ru: 'Стейк меню', en: 'Steak menu', kk: 'Стейк мәзірі' },
        items: [
          { name: 'Стейк Рибай', price: '10 500 ₸' },
          { name: 'Стейк из бараньего окорока', price: '10 500 ₸' },
          { name: 'Филе миньон', price: '10 500 ₸' },
          { name: 'Томленый стейк казы', price: '10 500 ₸' }
        ]
      },
      {
        id: 'pasta',
        title: { ru: 'Паста', en: 'Pasta', kk: 'Паста' },
        items: [
          { name: 'Папарделле с лососем', price: '5 300 ₸' },
          { name: 'Лингвини арабьята', price: '4 300 ₸' },
          { name: 'Ригатони с рваным мясом', price: '4 200 ₸' },
          { name: 'Спагетти болоньезе', price: '3 800 ₸' },
          { name: 'Паста Альфредо', price: '3 800 ₸' },
          { name: 'Ригатони в томатном соусе', price: '3 500 ₸' }
        ]
      },
      {
        id: 'pizza',
        title: { ru: 'Пицца', en: 'Pizza', kk: 'Пицца' },
        items: [
          { name: 'С морепродуктами', price: '5 200 ₸' },
          { name: 'Болоньезе', price: '4 200 ₸' },
          { name: 'Цыпленок ранч', price: '3 900 ₸' },
          { name: 'Цезарь', price: '4 200 ₸' },
          { name: 'Пепперони', price: '3 900 ₸' },
          { name: '4 сыра', price: '5 200 ₸' },
          { name: 'Маргарита', price: '3 600 ₸' }
        ]
      }
    ]
  }
];

window.renderEthnoMenu = function (language) {
  const index = document.getElementById('menu-index');
  const catalog = document.getElementById('menu-catalog');
  if (!index || !catalog) return;

  index.replaceChildren();
  catalog.replaceChildren();

  window.ethnoMenuData.forEach((group) => {
    const groupLabel = document.createElement('h2');
    groupLabel.className = 'menu-group-title';
    groupLabel.textContent = group.title[language] || group.title.ru;
    catalog.append(groupLabel);

    const groupLinks = document.createElement('div');
    groupLinks.className = 'menu-index-group';
    const groupLinksTitle = document.createElement('strong');
    groupLinksTitle.textContent = group.title[language] || group.title.ru;
    groupLinks.append(groupLinksTitle);

    group.sections.forEach((section) => {
      const title = section.title[language] || section.title.ru;
      const anchor = document.createElement('a');
      anchor.href = `#menu-${section.id}`;
      anchor.textContent = title;
      groupLinks.append(anchor);

      const sectionElement = document.createElement('section');
      sectionElement.className = 'menu-category';
      sectionElement.id = `menu-${section.id}`;

      const heading = document.createElement('h3');
      heading.textContent = title;
      sectionElement.append(heading);

      const list = document.createElement('div');
      list.className = 'menu-items-list';
      const localizedNames = window.ethnoMenuTranslations?.items?.[language]?.[section.id] || [];
      const localizedDescriptions = window.ethnoMenuTranslations?.descriptions?.[language] || {};

      section.items.forEach((item, itemIndex) => {
        const row = document.createElement('article');
        row.className = 'menu-item-row';

        const description = document.createElement('div');
        description.className = 'menu-item-copy';
        const name = document.createElement('h4');
        name.textContent = localizedNames[itemIndex] || item.name;
        description.append(name);

        if (item.description || item.size) {
          const details = document.createElement('p');
          details.className = 'menu-item-details';
          const translatedDescription = localizedDescriptions[item.description] || item.description;
          const translatedSize = language === 'en' ? item.size?.replaceAll('л', 'L') : item.size;
          details.textContent = [translatedDescription, translatedSize].filter(Boolean).join(' · ');
          description.append(details);
        }

        const price = document.createElement('strong');
        price.className = 'menu-item-price';
        price.textContent = item.price;
        row.append(description, price);
        list.append(row);
      });

      sectionElement.append(list);
      catalog.append(sectionElement);
    });

    index.append(groupLinks);
  });

  const note = document.createElement('p');
  note.className = 'menu-service-note';
  note.textContent = language === 'en'
    ? 'A 10% service charge applies.'
    : language === 'kk'
      ? 'Қызмет көрсету ақысы — 10%.'
      : 'Обслуживание 10%.';
  catalog.append(note);
};

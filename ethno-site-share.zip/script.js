const translations = {
  ru: {
    brand: 'Ethno',
    'nav.about': 'О ресторане',
    'nav.features': 'Преимущества',
    'nav.menu': 'Меню',
    'nav.contact': 'Контакты',
    booking: 'Забронировать столик',
    'review.button': 'Оставить отзыв',
    'menu.button': 'Смотреть меню',
    eyebrow: 'Рестораны • Актау',
    'hero.text': 'Казахская кухня, уютная атмосфера и живой опыт, который делает вечер особенным. В нашем ресторане сочетаются традиции, вкус и комфорт для всей семьи.',
    'hero.vip': 'VIP-зал',
    verified: 'Рейтинг 2GIS',
    'features.eyebrow': 'Почему выбирают нас',
    'features.title': 'Уют, традиции и атмосфера для идеального вечера',
    'feature1.title': 'Казахская кухня',
    'feature1.text': 'Аутентичные блюда, приготовленные с заботой о традициях и вкусе.',
    'feature2.title': 'VIP-залы',
    'feature2.text': 'Уютные отдельные залы для встреч и отдыха.',
    'feature2.gallery': 'Смотреть VIP-залы',
    'gallery.eyebrow': 'Интерьер Ethno',
    'gallery.title': 'Залы ресторана',
    'gallery.photo1': 'Основной зал',
    'gallery.photo2': 'Обеденный зал',
    'gallery.photo3': 'Интерьер ресторана',
    'vip.gallery.title': 'VIP-залы Ethno',
    'feature3.title': 'Живая музыка',
    'feature3.text': 'Панорамный интерьер, уютные кабинки и атмосфера для встреч и праздников.',
    'about.eyebrow': 'О ресторане',
    'about.title': 'Вкус, который остаётся в памяти.',
    'about.text1': 'Ethno — это место, где традиции казахской кулинарии встречаются с современным комфортом. Здесь гости могут насладиться блюдами из свежих ингредиентов и провести вечер в спокойной, тёплой атмосфере.',
    'about.text2': 'Мы создаём атмосферу для семейных ужинов, дружеских встреч и праздничных событий, где важны и вкус, и внимание к каждому гостю.',
    'menu.eyebrow': 'Наше меню',
    'menu.title': 'Что особенно любят гости',
    'menu.item1.name': 'Пицца',
    'menu.item1.tag': 'Сытно',
    'menu.item2.name': 'Бургеры',
    'menu.item2.tag': 'Классика',
    'menu.item3.name': 'Стейки',
    'menu.item3.tag': 'Премиум',
    'menu.item4.name': 'Салаты',
    'menu.item4.tag': 'Свежо',
    'menu.item5.name': 'Супы',
    'menu.item5.tag': 'Традиционно',
    'menu.item6.name': 'Бешбармак',
    'menu.item6.tag': 'Рекомендуем',
    'info.drinks': 'Напитки',
    'drinks.item1': 'Кофе с собой',
    'drinks.item2': 'Глинтвейн',
    'drinks.item3': 'Чай с собой',
    'info.extra': 'Дополнительно',
    'extra.item1': 'Молельная комната',
    'extra.item2': 'Wi‑Fi для клиентов',
    'extra.item3': 'Проведение банкетов',
    'info.payment': 'Способы оплаты',
    'payment.item1': 'Оплата картой',
    'payment.item2': 'Наличный расчёт',
    'payment.item3': 'Оплата через банк',
    'payment.item4': 'Оплата по QR‑коду',
    'info.transport': 'Транспорт',
    'transport.item1': 'Музыкальная школа',
    'transport.item2': '5 мин',
    'transport.item3': '500 м',
    'transport.item4': '2 парковки',
    'footer.text': 'Ресторан / кафе в Актау для семейного отдыха, встреч и вкусных традиций.',
    hours: 'Ежедневно с 11:00 до 24:00',
    'footer.booking': 'Забронировать столик',
    'footer.contact': 'Контакты',
    'menu.page.title': 'Меню Ethno',
    'menu.page.subtitle': 'Напитки и блюда ресторана',
    'menu.page.back': 'На главную',
    'menu.page.hero': 'Ethno · меню',
    'menu.page.item1': 'Пицца',
    'menu.page.item2': 'Бургер',
    'menu.page.item3': 'Стейк',
    'menu.page.item4': 'Бешбармак',
    'menu.page.item5': 'Салат',
    'menu.page.item6': 'Суп'
  },
  en: {
    brand: 'Ethno',
    'nav.about': 'About us',
    'nav.features': 'Highlights',
    'nav.menu': 'Menu',
    'nav.contact': 'Contacts',
    booking: 'Book a table',
    'review.button': 'Leave a review',
    'menu.button': 'View menu',
    eyebrow: 'Restaurants • Aktau',
    'hero.text': 'Kazakh cuisine, a cozy atmosphere and a vibrant experience that makes the evening unforgettable. Our restaurant blends traditions, taste and comfort for the whole family.',
    'hero.vip': 'VIP room',
    verified: '2GIS rating',
    'features.eyebrow': 'Why guests choose us',
    'features.title': 'Comfort, traditions and atmosphere for the perfect evening',
    'feature1.title': 'Kazakh cuisine',
    'feature1.text': 'Authentic dishes prepared with care for tradition and flavor.',
    'feature2.title': 'VIP rooms',
    'feature2.text': 'Comfortable private rooms for gatherings and dining.',
    'feature2.gallery': 'See VIP rooms',
    'gallery.eyebrow': 'Inside Ethno',
    'gallery.title': 'Restaurant rooms',
    'gallery.photo1': 'Main dining room',
    'gallery.photo2': 'Dining hall',
    'gallery.photo3': 'Restaurant interior',
    'vip.gallery.title': 'VIP rooms at Ethno',
    'feature3.title': 'Live music',
    'feature3.text': 'Panoramic interiors, cozy booths and a warm atmosphere for meetings and celebrations.',
    'about.eyebrow': 'About the restaurant',
    'about.title': 'A taste that stays in memory.',
    'about.text1': 'Ethno is a place where Kazakh culinary traditions meet modern comfort. Here guests can enjoy fresh ingredients and spend the evening in a calm, warm atmosphere.',
    'about.text2': 'We create an atmosphere for family dinners, friendly gatherings and celebrations where both taste and attention to every guest matter.',
    'menu.eyebrow': 'Our menu',
    'menu.title': 'What guests love most',
    'menu.item1.name': 'Pizza',
    'menu.item1.tag': 'Hearty',
    'menu.item2.name': 'Burgers',
    'menu.item2.tag': 'Classic',
    'menu.item3.name': 'Steaks',
    'menu.item3.tag': 'Premium',
    'menu.item4.name': 'Salads',
    'menu.item4.tag': 'Fresh',
    'menu.item5.name': 'Soups',
    'menu.item5.tag': 'Traditional',
    'menu.item6.name': 'Beshbarmak',
    'menu.item6.tag': 'Recommended',
    'info.drinks': 'Drinks',
    'drinks.item1': 'Coffee to go',
    'drinks.item2': 'Mulled wine',
    'drinks.item3': 'Tea to go',
    'info.extra': 'Additional',
    'extra.item1': 'Prayer room',
    'extra.item2': 'Wi‑Fi for guests',
    'extra.item3': 'Banquet service',
    'info.payment': 'Payment methods',
    'payment.item1': 'Card payment',
    'payment.item2': 'Cash payment',
    'payment.item3': 'Bank transfer',
    'payment.item4': 'QR code payment',
    'info.transport': 'Transport',
    'transport.item1': 'Music school',
    'transport.item2': '5 min',
    'transport.item3': '500 m',
    'transport.item4': '2 parking lots',
    'footer.text': 'Restaurant / Cafe in Aktau for family dinners, meetings and delicious traditions.',
    hours: 'Open daily from 11:00 to 24:00',
    'footer.booking': 'Book a table',
    'footer.contact': 'Contacts',
    'menu.page.title': 'Ethno Menu',
    'menu.page.subtitle': 'Drinks and restaurant dishes',
    'menu.page.back': 'Back home',
    'menu.page.hero': 'Ethno · menu',
    'menu.page.item1': 'Pizza',
    'menu.page.item2': 'Burger',
    'menu.page.item3': 'Steak',
    'menu.page.item4': 'Beshbarmak',
    'menu.page.item5': 'Salad',
    'menu.page.item6': 'Soup'
  },
  kk: {
    brand: 'Ethno',
    'nav.about': 'Ресторан туралы',
    'nav.features': 'Артықшылықтар',
    'nav.menu': 'Мәзір',
    'nav.contact': 'Байланыс',
    booking: 'Үстел брондау',
    'review.button': 'Пікір қалдыру',
    'menu.button': 'Мәзірді көру',
    eyebrow: 'Мейрамханалар • Ақтау',
    'hero.text': 'Қазақ асханасы, жайлы атмосфера және кешке ерекше ләззат беретін көңілді тәжірибе. Біздің ресторанымызда дәстүр, дәм және отбасы үшін жайлылық бірге жүреді.',
    'hero.vip': 'VIP-зал',
    verified: '2GIS рейтингі',
    'features.eyebrow': 'Неге бізді таңдайды',
    'features.title': 'Ыңғайлы, дәстүрлі және тамаша кешін жасау atmosферасы',
    'feature1.title': 'Қазақ асханасы',
    'feature1.text': 'Дәстүр мен дәмге қамқорлықпен дайындалған автентикалық тағамдар.',
    'feature2.title': 'VIP-залдар',
    'feature2.text': 'Кездесулер мен демалысқа арналған жайлы жеке залдар.',
    'feature2.gallery': 'VIP-залдарды көру',
    'gallery.eyebrow': 'Ethno интерьері',
    'gallery.title': 'Мейрамхана залдары',
    'gallery.photo1': 'Негізгі зал',
    'gallery.photo2': 'Ас ішу залы',
    'gallery.photo3': 'Мейрамхана интерьері',
    'vip.gallery.title': 'Ethno VIP-залдары',
    'feature3.title': 'Живая музыка',
    'feature3.text': 'Панорамалық интерьер, жайлы кабиналар және кездесулер мен тойлар үшін жылы атмосфера.',
    'about.eyebrow': 'Ресторан туралы',
    'about.title': 'Есте қалатын дәм.',
    'about.text1': 'Ethno — қазақ асханасының дәстүрлері заманауи жайлылықпен ұштасатын орын. Мұнда қонақтар жаңа өнімдерден жасалған тағамдарды рахаттана тамашалай алады.',
    'about.text2': 'Біз отбасы түскі асынан, достар кездесулерінен және мерекелерден жақсы әсер қалатын атмосфера жасаймыз.',
    'menu.eyebrow': 'Біздің мәзір',
    'menu.title': 'Қонақтар неге ерекше жақсы көреді',
    'menu.item1.name': 'Пицца',
    'menu.item1.tag': 'Толық',
    'menu.item2.name': 'Бургерлер',
    'menu.item2.tag': 'Классикалық',
    'menu.item3.name': 'Стейктер',
    'menu.item3.tag': 'Премиум',
    'menu.item4.name': 'Салаттар',
    'menu.item4.tag': 'Жаңартылған',
    'menu.item5.name': 'Сұйық тағамдар',
    'menu.item5.tag': 'Дәстүрлі',
    'menu.item6.name': 'Бешбармақ',
    'menu.item6.tag': 'Ұсынылады',
    'info.drinks': 'Ішу',
    'drinks.item1': 'С собой кофе',
    'drinks.item2': 'Глинтвейн',
    'drinks.item3': 'С собой шай',
    'info.extra': 'Қосымша',
    'extra.item1': 'Дін оқуы бөлмесі',
    'extra.item2': 'Клиенттерге Wi‑Fi',
    'extra.item3': 'Банкет өткізу',
    'info.payment': 'Төлем тәсілдері',
    'payment.item1': 'Карточка арқылы төлеу',
    'payment.item2': 'Нақты ақша',
    'payment.item3': 'Банк арқылы төлеу',
    'payment.item4': 'QR-код арқылы төлеу',
    'info.transport': 'Көлік',
    'transport.item1': 'Музыкалық мектеп',
    'transport.item2': '5 мин',
    'transport.item3': '500 м',
    'transport.item4': '2 parkeren',
    'footer.text': 'Ақтаудағы отбасылық кештер, кездесулер және дәмді дәстүрлер үшін ресторан / кафе.',
    hours: 'Күн сайын 11:00-ден 24:00-ге дейін',
    'footer.booking': 'Үстел брондау',
    'footer.contact': 'Байланыс',
    'menu.page.title': 'Ethno мәзірі',
    'menu.page.subtitle': 'Сусындар мен мейрамхана тағамдары',
    'menu.page.back': 'Басты бетке',
    'menu.page.hero': 'Ethno · мәзір',
    'menu.page.item1': 'Пицца',
    'menu.page.item2': 'Бургер',
    'menu.page.item3': 'Стейк',
    'menu.page.item4': 'Бешбармақ',
    'menu.page.item5': 'Салат',
    'menu.page.item6': 'Суп'
  }
};

const yearNode = document.getElementById('currentYear');
if (yearNode) {
  yearNode.textContent = `© ${new Date().getFullYear()}`;
}

const getStoredLanguage = () => {
  try {
    return localStorage.getItem('ethno-lang') || 'ru';
  } catch (error) {
    return 'ru';
  }
};

const langButtons = document.querySelectorAll('.lang-btn');
const translatableNodes = document.querySelectorAll('[data-i18n]');

function applyLanguage(lang) {
  const language = translations[lang] ? lang : 'ru';
  const dictionary = translations[language];

  try {
    localStorage.setItem('ethno-lang', language);
  } catch (error) {}

  document.documentElement.lang = language;

  translatableNodes.forEach((node) => {
    const key = node.dataset.i18n;
    if (dictionary[key]) {
      node.textContent = dictionary[key];
    }
  });

  langButtons.forEach((button) => {
    const isActive = button.dataset.lang === language;
    button.classList.toggle('active', isActive);
    button.setAttribute('aria-pressed', String(isActive));
  });

  if (typeof window !== 'undefined' && typeof window.renderEthnoMenu === 'function') {
    window.renderEthnoMenu(language);
  }
}

langButtons.forEach((button) => {
  button.addEventListener('click', () => applyLanguage(button.dataset.lang));
});

const buttons = document.querySelectorAll('.btn');
buttons.forEach((button) => {
  button.addEventListener('click', () => {
    button.classList.add('pulse');
    setTimeout(() => button.classList.remove('pulse'), 250);
  });
});

document.querySelectorAll('[data-open-gallery]').forEach((button) => {
  button.addEventListener('click', () => {
    document.getElementById(button.dataset.openGallery)?.showModal();
  });
});

document.querySelectorAll('[data-close-gallery]').forEach((button) => {
  button.addEventListener('click', () => button.closest('dialog')?.close());
});

document.querySelectorAll('.vip-dialog').forEach((dialog) => {
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close();
  });
});

applyLanguage(getStoredLanguage());
